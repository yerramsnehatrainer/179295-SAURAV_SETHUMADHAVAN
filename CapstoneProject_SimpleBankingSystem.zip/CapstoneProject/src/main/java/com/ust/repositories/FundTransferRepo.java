package com.ust.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ust.entity.FundTransfer;


@Repository
public interface FundTransferRepo extends JpaRepository<FundTransfer, Integer> {
//	FundTransfer findByAccount_no(long account_no);

}
